<div class="panel widget center bgimg" style="margin-bottom:0;overflow:hidden;background-color:rgb(0, 225, 255);">
    <div class="dimmer"></div>
    <div class="panel-content">
        <?php if(isset($icon)): ?><i class='<?php echo e($icon); ?>'></i><?php endif; ?>
        <h4><?php echo $title; ?></h4>
        <p><?php echo $text; ?></p>
        <a href="<?php echo e($button['link']); ?>" class="btn btn-primary"><?php echo $button['text']; ?></a>
    </div>
</div>
<?php /**PATH D:\Kehidupan\BWS\Sistem Informasi OP\simop\vendor\tcg\voyager\src/../resources/views/dimmer.blade.php ENDPATH**/ ?>